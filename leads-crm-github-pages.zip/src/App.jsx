import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  BarChart3,
  Bell,
  Check,
  ChevronLeft,
  ClipboardList,
  LayoutDashboard,
  MessageCircle,
  Plus,
  RotateCcw,
  Search,
  UserRound,
  Users,
} from "lucide-react";
import "./index.css";

function Card({ className = "", children }) {
  return <div className={`rounded-3xl bg-white ${className}`}>{children}</div>;
}

function CardContent({ className = "", children }) {
  return <div className={className}>{children}</div>;
}

function Button({ className = "", variant = "default", children, ...props }) {
  const base =
    "inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-bold transition disabled:opacity-50 disabled:pointer-events-none";
  const variants = {
    default: "bg-slate-950 text-white hover:bg-slate-800",
    outline: "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
  };

  return (
    <button className={`${base} ${variants[variant] || variants.default} ${className}`} {...props}>
      {children}
    </button>
  );
}

function Input({ className = "", ...props }) {
  return (
    <input
      className={`w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100 ${className}`}
      {...props}
    />
  );
}

function Textarea({ className = "", ...props }) {
  return (
    <textarea
      className={`w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100 ${className}`}
      {...props}
    />
  );
}

const statuses = ["חדש", "בטיפול", "לא ענה", "לחזור אליו", "שיחה נקבעה", "נסגר / נמכר", "לא רלוונטי"];
const LEAD_SOURCE = "טופס - דר אירית שחם";

const workers = [
  { id: "w-0", name: "שגיא", active: true, role: "גרפיקה" },
  { id: "w-1", name: "לואיזה", active: true, role: "מכירות" },
  { id: "w-2", name: "דניאל", active: true, role: "מכירות" },
  { id: "w-3", name: "ליהי", active: true, role: "מכירות" },
  { id: "w-4", name: "נלי", active: true, role: "מדריכה ומכירות" },
  { id: "w-5", name: "אורית", active: true, role: "מנהלת משרד ומכירות" },
  { id: "w-6", name: "שילי", active: true, role: "מנהלת שיווק" },
  { id: "w-7", name: "שני", active: true, role: "יוצרת תוכן" },
  { id: "w-8", name: "קרן", active: true, role: "אתרים" },
  { id: "w-9", name: "חוה", active: true, role: "לוגיסטיקה" },
  { id: "w-10", name: "גיירן", active: true, role: "גביה" },
];

const initialTasks = [
  {
    id: "T-2001",
    title: "לחזור ללירון כהן",
    description: "לתאם שיחה ולהבין איזה טיפול פילינג רלוונטי עבורה.",
    ownerId: "w-1",
    relatedLeadId: "L-1001",
    status: "פתוחה",
    priority: "גבוהה",
    dueDate: "2026-05-23",
    createdAt: "2026-05-23",
  },
  {
    id: "T-2002",
    title: "לשלוח וואטסאפ לורד מויאל",
    description: "לשלוח הודעת פתיחה עם פרטי הקליניקה ושעות זמינות.",
    ownerId: "w-2",
    relatedLeadId: "L-1002",
    status: "בתהליך",
    priority: "בינונית",
    dueDate: "2026-05-23",
    createdAt: "2026-05-23",
  },
  {
    id: "T-2003",
    title: "להכין גרפיקה לקמפיין פילינגים",
    description: "ויזואל סטורי וגרסת פיד לקמפיין דר אירית שחם.",
    ownerId: "w-0",
    relatedLeadId: "",
    status: "פתוחה",
    priority: "בינונית",
    dueDate: "2026-05-24",
    createdAt: "2026-05-23",
  },
  {
    id: "T-2004",
    title: "בדיקת מלאי לפני תיאום טיפולים",
    description: "לוודא זמינות חומרים רלוונטיים לטיפולי מרקם עור.",
    ownerId: "w-9",
    relatedLeadId: "",
    status: "הושלמה",
    priority: "נמוכה",
    dueDate: "2026-05-22",
    createdAt: "2026-05-22",
  },
];

const taskStatuses = ["פתוחה", "בתהליך", "הושלמה"];
const priorities = ["נמוכה", "בינונית", "גבוהה"];

const initialLeads = [
  {
    id: "L-1001",
    fullName: "לירון כהן",
    phone: "054-2095258",
    email: "",
    city: "רמת השרון",
    source: LEAD_SOURCE,
    product: "טיפולי מרקם עור - פילינגים",
    status: "חדש",
    ownerId: "w-1",
    createdAt: "2026-05-19",
    followUpAt: "2026-05-19",
    notes: ["התקבל מהטופס בתאריך 19.05.2026 בשעה 17:18. מיקום: כן, רלוונטי מאוד."],
    lastAction: "ליד חדש מהטופס",
    saleAmount: 0,
  },
  {
    id: "L-1002",
    fullName: "ורד מויאל",
    phone: "050-3822203",
    email: "",
    city: "רמת השרון",
    source: LEAD_SOURCE,
    product: "טיפולי מרקם עור - פילינגים",
    status: "חדש",
    ownerId: "w-2",
    createdAt: "2026-05-19",
    followUpAt: "2026-05-19",
    notes: ["התקבל מהטופס בתאריך 19.05.2026 בשעה 18:54. מיקום: כן, רלוונטי מאוד."],
    lastAction: "ליד חדש מהטופס",
    saleAmount: 0,
  },
  {
    id: "L-1003",
    fullName: "לימור מלא בן הרוש",
    phone: "050-9447890",
    email: "",
    city: "רמת השרון",
    source: LEAD_SOURCE,
    product: "פגישת ייעוץ כללית",
    status: "חדש",
    ownerId: "w-3",
    createdAt: "2026-05-19",
    followUpAt: "2026-05-19",
    notes: ["התקבל מהטופס בתאריך 19.05.2026 בשעה 19:41. מיקום: כן, רלוונטי מאוד."],
    lastAction: "ליד חדש מהטופס",
    saleAmount: 0,
  },
  {
    id: "L-1004",
    fullName: "גילת לוין",
    phone: "050-7450967",
    email: "",
    city: "רמת השרון",
    source: LEAD_SOURCE,
    product: "טיפולי מרקם עור - פילינגים",
    status: "חדש",
    ownerId: "w-4",
    createdAt: "2026-05-20",
    followUpAt: "2026-05-20",
    notes: ["התקבל מהטופס בתאריך 20.05.2026 בשעה 03:54. מיקום: כן, רלוונטי מאוד."],
    lastAction: "ליד חדש מהטופס",
    saleAmount: 0,
  },
  {
    id: "L-1005",
    fullName: "איילה כהן",
    phone: "050-6286609",
    email: "",
    city: "רמת השרון",
    source: LEAD_SOURCE,
    product: "טיפולי מרקם עור - פילינגים",
    status: "חדש",
    ownerId: "w-5",
    createdAt: "2026-05-23",
    followUpAt: "2026-05-23",
    notes: ["התקבל מהטופס בתאריך 23.05.2026 בשעה 02:10. מיקום: כן, רלוונטי מאוד."],
    lastAction: "ליד חדש מהטופס",
    saleAmount: 0,
  },
  {
    id: "L-1006",
    fullName: "מיכל בידאני",
    phone: "052-6958897",
    email: "",
    city: "רמת השרון",
    source: LEAD_SOURCE,
    product: "טיפולי מרקם עור - פילינגים",
    status: "חדש",
    ownerId: "w-6",
    createdAt: "2026-05-23",
    followUpAt: "2026-05-23",
    notes: ["התקבל מהטופס בתאריך 23.05.2026 בשעה 02:11. מיקום: כן, רלוונטי מאוד."],
    lastAction: "ליד חדש מהטופס",
    saleAmount: 0,
  },
  {
    id: "L-1007",
    fullName: "מיכל מלכה",
    phone: "054-9987799",
    email: "",
    city: "רמת השרון",
    source: LEAD_SOURCE,
    product: "טיפולי מרקם עור - פילינגים",
    status: "חדש",
    ownerId: "w-7",
    createdAt: "2026-05-23",
    followUpAt: "2026-05-23",
    notes: ["התקבל מהטופס בתאריך 23.05.2026 בשעה 04:57. מיקום: כן, רלוונטי מאוד."],
    lastAction: "ליד חדש מהטופס",
    saleAmount: 0,
  },
  {
    id: "L-1008",
    fullName: "כרמלה",
    phone: "052-5550912",
    email: "",
    city: "רחוק מרמת השרון",
    source: LEAD_SOURCE,
    product: "פיסול פנים - nexha mesoestetic",
    status: "לא רלוונטי",
    ownerId: "w-8",
    createdAt: "2026-05-23",
    followUpAt: "",
    notes: ["התקבל מהטופס בתאריך 23.05.2026 בשעה 10:12. מיקום: לא, רחוק לי מדי."],
    lastAction: "סומן כלא רלוונטי לפי מיקום",
    saleAmount: 0,
  },
];

function cx(...classes) {
  return classes.filter(Boolean).join(" ");
}

function formatDate(dateString) {
  if (!dateString) return "—";
  return new Date(`${dateString}T00:00:00`).toLocaleDateString("he-IL");
}

function getWorkerName(ownerId) {
  return workers.find((worker) => worker.id === ownerId)?.name || "לא משויך";
}

function useLocalStorageState(key, defaultValue) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : defaultValue;
    } catch {
      return defaultValue;
    }
  });

  const updateValue = (nextValue) => {
    setValue((previous) => {
      const resolved = typeof nextValue === "function" ? nextValue(previous) : nextValue;
      localStorage.setItem(key, JSON.stringify(resolved));
      return resolved;
    });
  };

  return [value, updateValue];
}

function StatCard({ icon: Icon, title, value, subtitle }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-slate-500">{title}</p>
            <p className="mt-2 text-3xl font-bold text-slate-950">{value}</p>
            {subtitle && <p className="mt-1 text-xs text-slate-500">{subtitle}</p>}
          </div>
          <div className="rounded-2xl bg-slate-100 p-3 text-slate-700">
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function StatusPill({ status }) {
  const styleMap = {
    "חדש": "bg-blue-50 text-blue-700 border-blue-100",
    "בטיפול": "bg-amber-50 text-amber-700 border-amber-100",
    "לא ענה": "bg-orange-50 text-orange-700 border-orange-100",
    "לחזור אליו": "bg-purple-50 text-purple-700 border-purple-100",
    "שיחה נקבעה": "bg-cyan-50 text-cyan-700 border-cyan-100",
    "נסגר / נמכר": "bg-emerald-50 text-emerald-700 border-emerald-100",
    "לא רלוונטי": "bg-slate-100 text-slate-600 border-slate-200",
  };

  return (
    <span className={cx("inline-flex rounded-full border px-3 py-1 text-xs font-bold", styleMap[status])}>
      {status}
    </span>
  );
}

function SidebarButton({ active, icon: Icon, children, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cx(
        "flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-right text-sm font-bold transition",
        active ? "bg-slate-950 text-white shadow-md" : "text-slate-600 hover:bg-slate-100"
      )}
    >
      <Icon className="h-5 w-5" />
      <span>{children}</span>
    </button>
  );
}

function EmptyState({ title, subtitle }) {
  return (
    <div className="rounded-3xl border border-dashed border-slate-200 bg-white p-10 text-center">
      <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100">
        <ClipboardList className="h-6 w-6 text-slate-500" />
      </div>
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
    </div>
  );
}

function App() {
  const [activeScreen, setActiveScreen] = useState("dashboard");
  const [leads, setLeads] = useLocalStorageState("leads-crm-leads", initialLeads);
  const [tasks, setTasks] = useLocalStorageState("leads-crm-tasks", initialTasks);
  const [selectedLeadId, setSelectedLeadId] = useState(initialLeads[0]?.id);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("הכל");
  const [ownerFilter, setOwnerFilter] = useState("הכל");
  const [newNote, setNewNote] = useState("");
  const [newLead, setNewLead] = useState({ fullName: "", phone: "", email: "", city: "", product: "" });
  const [taskStatusFilter, setTaskStatusFilter] = useState("הכל");
  const [taskOwnerFilter, setTaskOwnerFilter] = useState("הכל");
  const [newTask, setNewTask] = useState({ title: "", description: "", ownerId: "w-1", relatedLeadId: "", priority: "בינונית", dueDate: "2026-05-23" });
  const [nextWorkerIndex, setNextWorkerIndex] = useLocalStorageState("leads-crm-next-worker-index", 9);

  const today = "2026-05-23";

  const selectedLead = leads.find((lead) => lead.id === selectedLeadId) || leads[0];

  const filteredLeads = useMemo(() => {
    return leads.filter((lead) => {
      const normalizedQuery = query.trim().toLowerCase();
      const matchesQuery = !normalizedQuery
        || lead.fullName.toLowerCase().includes(normalizedQuery)
        || lead.phone.includes(normalizedQuery)
        || lead.email.toLowerCase().includes(normalizedQuery)
        || lead.city.toLowerCase().includes(normalizedQuery);
      const matchesStatus = statusFilter === "הכל" || lead.status === statusFilter;
      const matchesOwner = ownerFilter === "הכל" || lead.ownerId === ownerFilter;
      return matchesQuery && matchesStatus && matchesOwner;
    });
  }, [leads, ownerFilter, query, statusFilter]);

  const metrics = useMemo(() => {
    const incomingToday = leads.filter((lead) => lead.createdAt === today).length;
    const closed = leads.filter((lead) => lead.status === "נסגר / נמכר");
    const open = leads.filter((lead) => !["נסגר / נמכר", "לא רלוונטי"].includes(lead.status)).length;
    const dueFollowups = leads.filter((lead) => lead.followUpAt && lead.followUpAt <= today && lead.status !== "נסגר / נמכר").length;
    const totalSales = closed.reduce((sum, lead) => sum + lead.saleAmount, 0);
    const conversionRate = leads.length ? Math.round((closed.length / leads.length) * 100) : 0;
    return { incomingToday, closed: closed.length, open, dueFollowups, totalSales, conversionRate };
  }, [leads]);

  const statusCounts = useMemo(() => {
    return statuses.map((status) => ({
      status,
      count: leads.filter((lead) => lead.status === status).length,
    }));
  }, [leads]);

  const workerStats = useMemo(() => {
    return workers.map((worker) => {
      const workerLeads = leads.filter((lead) => lead.ownerId === worker.id);
      const closed = workerLeads.filter((lead) => lead.status === "נסגר / נמכר");
      const workerTasks = tasks.filter((task) => task.ownerId === worker.id);
      const completedTasks = workerTasks.filter((task) => task.status === "הושלמה");
      const openTasks = workerTasks.filter((task) => task.status !== "הושלמה");
      return {
        ...worker,
        total: workerLeads.length,
        closed: closed.length,
        tasksTotal: workerTasks.length,
        tasksDone: completedTasks.length,
        tasksOpen: openTasks.length,
        revenue: closed.reduce((sum, lead) => sum + lead.saleAmount, 0),
      };
    });
  }, [leads, tasks]);

  const followups = useMemo(() => {
    return leads
      .filter((lead) => lead.followUpAt && lead.status !== "נסגר / נמכר")
      .sort((a, b) => a.followUpAt.localeCompare(b.followUpAt));
  }, [leads]);

  const taskMetrics = useMemo(() => {
    const open = tasks.filter((task) => task.status !== "הושלמה").length;
    const completed = tasks.filter((task) => task.status === "הושלמה").length;
    const overdue = tasks.filter((task) => task.status !== "הושלמה" && task.dueDate && task.dueDate < today).length;
    return { open, completed, overdue, total: tasks.length };
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => taskStatusFilter === "הכל" || task.status === taskStatusFilter)
      .filter((task) => taskOwnerFilter === "הכל" || task.ownerId === taskOwnerFilter)
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  }, [tasks, taskOwnerFilter, taskStatusFilter]);

  const getLeadName = (leadId) => {
    if (!leadId) return "ללא ליד מקושר";
    return leads.find((lead) => lead.id === leadId)?.fullName || "ליד לא נמצא";
  };

  const updateTask = (taskId, changes) => {
    setTasks((prev) => prev.map((task) => (task.id === taskId ? { ...task, ...changes } : task)));
  };

  const addTask = () => {
    if (!newTask.title.trim()) return;

    const task = {
      id: `T-${2000 + tasks.length + 1}`,
      title: newTask.title.trim(),
      description: newTask.description.trim(),
      ownerId: newTask.ownerId,
      relatedLeadId: newTask.relatedLeadId,
      status: "פתוחה",
      priority: newTask.priority,
      dueDate: newTask.dueDate || today,
      createdAt: today,
    };

    setTasks((prev) => [task, ...prev]);
    setNewTask({ title: "", description: "", ownerId: "w-1", relatedLeadId: "", priority: "בינונית", dueDate: today });
  };

  const updateLead = (leadId, changes) => {
    setLeads((prev) => prev.map((lead) => (lead.id === leadId ? { ...lead, ...changes } : lead)));
  };

  const addNote = () => {
    if (!selectedLead || !newNote.trim()) return;
    updateLead(selectedLead.id, {
      notes: [`${new Date().toLocaleString("he-IL")}: ${newNote.trim()}`, ...selectedLead.notes],
      lastAction: "נוספה הערה חדשה",
    });
    setNewNote("");
  };

  const sendWhatsapp = () => {
    if (!selectedLead) return;
    updateLead(selectedLead.id, {
      notes: [`${new Date().toLocaleString("he-IL")}: נשלחה הודעת וואטסאפ ללקוח`, ...selectedLead.notes],
      lastAction: "נשלחה הודעת וואטסאפ",
      status: selectedLead.status === "חדש" ? "בטיפול" : selectedLead.status,
    });
  };

  const addLead = () => {
    if (!newLead.fullName.trim() || !newLead.phone.trim()) return;

    const activeWorkers = workers.filter((worker) => worker.active);
    const assignedWorker = activeWorkers[nextWorkerIndex % activeWorkers.length];
    const nextId = `L-${1000 + leads.length + 1}`;

    const lead = {
      id: nextId,
      fullName: newLead.fullName.trim(),
      phone: newLead.phone.trim(),
      email: newLead.email.trim(),
      city: newLead.city.trim(),
      source: LEAD_SOURCE,
      product: newLead.product.trim() || "לא צוין",
      status: "חדש",
      ownerId: assignedWorker.id,
      createdAt: today,
      followUpAt: today,
      notes: [`ליד חדש נוסף וחולק אוטומטית אל ${assignedWorker.name}`],
      lastAction: "ליד חדש נכנס מהטופס",
      saleAmount: 0,
    };

    setLeads((prev) => [lead, ...prev]);
    setSelectedLeadId(nextId);
    setNextWorkerIndex((prev) => prev + 1);
    setNewLead({ fullName: "", phone: "", email: "", city: "", product: "" });
    setActiveScreen("leads");
  };

  const resetDemo = () => {
    setLeads(initialLeads);
    setTasks(initialTasks);
    setNextWorkerIndex(9);
    setSelectedLeadId(initialLeads[0]?.id);
    setQuery("");
    setStatusFilter("הכל");
    setOwnerFilter("הכל");
    setNewNote("");
    setNewLead({ fullName: "", phone: "", email: "", city: "", product: "" });
    setTaskStatusFilter("הכל");
    setTaskOwnerFilter("הכל");
    setNewTask({ title: "", description: "", ownerId: "w-1", relatedLeadId: "", priority: "בינונית", dueDate: today });
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-950">
      <div className="flex min-h-screen flex-col lg:flex-row">
        <aside className="border-b border-slate-200 bg-white p-4 lg:w-72 lg:border-b-0 lg:border-l">
          <div className="mb-6 rounded-3xl bg-slate-950 p-5 text-white">
            <p className="text-sm text-slate-300">MVP דמו</p>
            <h1 className="mt-1 text-2xl font-bold">ניהול לידים ומכירות</h1>
            <p className="mt-2 text-sm text-slate-300">טופס לידים + WhatsApp</p>
          </div>

          <nav className="grid gap-2">
            <SidebarButton active={activeScreen === "dashboard"} icon={LayoutDashboard} onClick={() => setActiveScreen("dashboard")}>דשבורד מנהלים</SidebarButton>
            <SidebarButton active={activeScreen === "leads"} icon={ClipboardList} onClick={() => setActiveScreen("leads")}>לידים</SidebarButton>
            <SidebarButton active={activeScreen === "followups"} icon={Bell} onClick={() => setActiveScreen("followups")}>תזכורות Follow-up</SidebarButton>
            <SidebarButton active={activeScreen === "tasks"} icon={Check} onClick={() => setActiveScreen("tasks")}>ניהול משימות</SidebarButton>
            <SidebarButton active={activeScreen === "reports"} icon={BarChart3} onClick={() => setActiveScreen("reports")}>דוחות</SidebarButton>
            <SidebarButton active={activeScreen === "team"} icon={Users} onClick={() => setActiveScreen("team")}>צוות והרשאות</SidebarButton>
          </nav>

          <Button variant="outline" onClick={resetDemo} className="mt-6 w-full">
            <RotateCcw className="ml-2 h-4 w-4" />
            איפוס דמו
          </Button>
        </aside>

        <main className="flex-1 p-4 md:p-8">
          <div className="mx-auto max-w-7xl space-y-6">
            <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm font-bold text-slate-500">מערכת פנימית ל־11 עובדים</p>
                <h2 className="text-3xl font-bold tracking-tight">
                  {activeScreen === "dashboard" && "דשבורד מנהלים"}
                  {activeScreen === "leads" && "ניהול לידים"}
                  {activeScreen === "followups" && "תזכורות Follow-up"}
                  {activeScreen === "tasks" && "ניהול משימות"}
                  {activeScreen === "reports" && "דוחות מכירות"}
                  {activeScreen === "team" && "צוות והרשאות"}
                </h2>
              </div>

              <Button onClick={() => setActiveScreen("leads")}>
                <Plus className="ml-2 h-4 w-4" />
                הוספת ליד דמו
              </Button>
            </header>

            {activeScreen === "dashboard" && (
              <div className="space-y-6">
                <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
                  <StatCard icon={ClipboardList} title="לידים שנכנסו היום" value={metrics.incomingToday} subtitle="מקור: טופס - דר אירית שחם" />
                  <StatCard icon={Check} title="סגירות" value={metrics.closed} subtitle={`המרה: ${metrics.conversionRate}%`} />
                  <StatCard icon={Bell} title="תזכורות פתוחות" value={metrics.dueFollowups} subtitle="דורש טיפול היום" />
                  <StatCard icon={Users} title="משימות פתוחות" value={taskMetrics.open} subtitle={`${taskMetrics.completed} הושלמו`} />
                  <StatCard icon={BarChart3} title="סך מכירות" value={`₪${metrics.totalSales.toLocaleString("he-IL")}`} subtitle="לפי עסקאות סגורות" />
                </section>

                <section className="grid gap-6 xl:grid-cols-2">
                  <Card className="border-0 shadow-sm">
                    <CardContent className="p-5">
                      <h3 className="mb-4 text-xl font-bold">משפך לפי סטטוס</h3>
                      <div className="space-y-3">
                        {statusCounts.map(({ status, count }) => {
                          const width = leads.length ? Math.max(8, Math.round((count / leads.length) * 100)) : 0;
                          return (
                            <div key={status}>
                              <div className="mb-1 flex justify-between text-sm">
                                <span className="font-bold">{status}</span>
                                <span className="text-slate-500">{count}</span>
                              </div>
                              <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                                <div className="h-full rounded-full bg-slate-950" style={{ width: `${width}%` }} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-sm">
                    <CardContent className="p-5">
                      <h3 className="mb-4 text-xl font-bold">ביצועים לפי עובד</h3>
                      <div className="space-y-3">
                        {workerStats.map((worker) => (
                          <div key={worker.id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-3">
                            <div className="flex items-center gap-3">
                              <div className="rounded-2xl bg-white p-2">
                                <UserRound className="h-5 w-5 text-slate-500" />
                              </div>
                              <div>
                                <p className="font-bold">{worker.name}</p>
                                <p className="text-xs text-slate-500">{worker.total} לידים · {worker.closed} סגירות</p>
                                <p className="text-xs text-slate-500">{worker.tasksOpen} משימות פתוחות · {worker.tasksDone} הושלמו</p>
                              </div>
                            </div>
                            <p className="font-bold">₪{worker.revenue.toLocaleString("he-IL")}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </section>
              </div>
            )}

            {activeScreen === "leads" && (
              <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
                <section className="space-y-4">
                  <Card className="border-0 shadow-sm">
                    <CardContent className="p-5">
                      <h3 className="mb-4 text-xl font-bold">הוספת ליד חדש מהטופס / ידנית</h3>
                      <div className="grid gap-3 md:grid-cols-2">
                        <Input value={newLead.fullName} onChange={(e) => setNewLead({ ...newLead, fullName: e.target.value })} placeholder="שם מלא" />
                        <Input value={newLead.phone} onChange={(e) => setNewLead({ ...newLead, phone: e.target.value })} placeholder="טלפון" />
                        <Input value={newLead.email} onChange={(e) => setNewLead({ ...newLead, email: e.target.value })} placeholder="אימייל" />
                        <Input value={newLead.city} onChange={(e) => setNewLead({ ...newLead, city: e.target.value })} placeholder="עיר / אזור" />
                        <Input value={newLead.product} onChange={(e) => setNewLead({ ...newLead, product: e.target.value })} placeholder="מוצר / שירות" className="md:col-span-2" />
                      </div>
                      <Button onClick={addLead} className="mt-4">
                        <Plus className="ml-2 h-4 w-4" />
                        הוספה וחלוקה אוטומטית
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-sm">
                    <CardContent className="p-5">
                      <div className="mb-4 grid gap-3 md:grid-cols-[1fr_180px_180px]">
                        <div className="relative">
                          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="חיפוש לפי שם, טלפון, אימייל או עיר" className="pr-10" />
                        </div>

                        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                          <option>הכל</option>
                          {statuses.map((status) => <option key={status}>{status}</option>)}
                        </select>

                        <select value={ownerFilter} onChange={(e) => setOwnerFilter(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                          <option value="הכל">כל העובדים</option>
                          {workers.map((worker) => <option key={worker.id} value={worker.id}>{worker.name}</option>)}
                        </select>
                      </div>

                      <div className="space-y-2">
                        {filteredLeads.length === 0 && <EmptyState title="לא נמצאו לידים" subtitle="נסי לשנות חיפוש או פילטרים." />}
                        {filteredLeads.map((lead) => (
                          <button
                            key={lead.id}
                            type="button"
                            onClick={() => setSelectedLeadId(lead.id)}
                            className={cx(
                              "w-full rounded-3xl border bg-white p-4 text-right transition hover:border-slate-400 hover:shadow-sm",
                              selectedLead?.id === lead.id ? "border-slate-950 shadow-sm" : "border-slate-100"
                            )}
                          >
                            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="font-bold">{lead.fullName}</h4>
                                  <StatusPill status={lead.status} />
                                </div>
                                <p className="mt-1 text-sm text-slate-500">{lead.phone} · {lead.city} · {lead.product}</p>
                                <p className="mt-1 text-xs text-slate-400">מטפל: {getWorkerName(lead.ownerId)} · מקור: {lead.source}</p>
                              </div>
                              <ChevronLeft className="hidden h-5 w-5 text-slate-400 md:block" />
                            </div>
                          </button>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </section>

                <section className="xl:sticky xl:top-8 xl:h-fit">
                  {!selectedLead ? (
                    <EmptyState title="בחרי ליד" subtitle="כרטיס הליד יופיע כאן." />
                  ) : (
                    <Card className="border-0 shadow-sm">
                      <CardContent className="space-y-5 p-5">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <h3 className="text-2xl font-bold">{selectedLead.fullName}</h3>
                            <p className="mt-1 text-sm text-slate-500">{selectedLead.phone} · {selectedLead.email}</p>
                          </div>
                          <StatusPill status={selectedLead.status} />
                        </div>

                        <div className="grid gap-3 rounded-3xl bg-slate-50 p-4 text-sm md:grid-cols-2">
                          <div><span className="text-slate-500">עיר:</span> <b>{selectedLead.city}</b></div>
                          <div><span className="text-slate-500">מוצר:</span> <b>{selectedLead.product}</b></div>
                          <div><span className="text-slate-500">עובד מטפל:</span> <b>{getWorkerName(selectedLead.ownerId)}</b></div>
                          <div><span className="text-slate-500">תאריך פנייה:</span> <b>{formatDate(selectedLead.createdAt)}</b></div>
                          <div><span className="text-slate-500">Follow-up:</span> <b>{formatDate(selectedLead.followUpAt)}</b></div>
                          <div><span className="text-slate-500">פעולה אחרונה:</span> <b>{selectedLead.lastAction}</b></div>
                        </div>

                        <div className="grid gap-3 md:grid-cols-2">
                          <label className="text-sm font-bold">
                            שינוי סטטוס
                            <select
                              value={selectedLead.status}
                              onChange={(e) => updateLead(selectedLead.id, { status: e.target.value, lastAction: `סטטוס עודכן ל-${e.target.value}` })}
                              className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm"
                            >
                              {statuses.map((status) => <option key={status}>{status}</option>)}
                            </select>
                          </label>

                          <label className="text-sm font-bold">
                            תאריך Follow-up
                            <Input
                              type="date"
                              value={selectedLead.followUpAt}
                              onChange={(e) => updateLead(selectedLead.id, { followUpAt: e.target.value, lastAction: "עודכן Follow-up" })}
                              className="mt-2"
                            />
                          </label>
                        </div>

                        <div className="grid gap-2 md:grid-cols-2">
                          <Button onClick={sendWhatsapp} className="bg-emerald-600 hover:bg-emerald-700">
                            <MessageCircle className="ml-2 h-4 w-4" />
                            שליחת WhatsApp
                          </Button>
                          <Button variant="outline" onClick={() => updateLead(selectedLead.id, { status: "נסגר / נמכר", saleAmount: selectedLead.saleAmount || 3500, lastAction: "סומן כנסגר" })}>
                            <Check className="ml-2 h-4 w-4" />
                            סימון כסגור
                          </Button>
                        </div>

                        <div>
                          <h4 className="mb-2 font-bold">הוספת הערה</h4>
                          <Textarea value={newNote} onChange={(e) => setNewNote(e.target.value)} placeholder="כתבי הערה על הליד..." className="min-h-24" />
                          <Button onClick={addNote} className="mt-2">שמירת הערה</Button>
                        </div>

                        <div>
                          <h4 className="mb-2 font-bold">היסטוריית הערות ופעולות</h4>
                          <div className="max-h-60 space-y-2 overflow-auto rounded-3xl bg-slate-50 p-3">
                            {selectedLead.notes.map((note, index) => (
                              <div key={`${note}-${index}`} className="rounded-2xl bg-white p-3 text-sm text-slate-700 shadow-sm">
                                {note}
                              </div>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </section>
              </div>
            )}

            {activeScreen === "followups" && (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-5">
                  <h3 className="mb-4 text-xl font-bold">תזכורות לחזרה ללקוחות</h3>
                  <div className="space-y-3">
                    {followups.map((lead) => (
                      <div key={lead.id} className="flex flex-col gap-3 rounded-3xl bg-slate-50 p-4 md:flex-row md:items-center md:justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold">{lead.fullName}</h4>
                            <StatusPill status={lead.status} />
                          </div>
                          <p className="mt-1 text-sm text-slate-500">לחזור בתאריך {formatDate(lead.followUpAt)} · מטפל: {getWorkerName(lead.ownerId)}</p>
                        </div>
                        <Button onClick={() => { setSelectedLeadId(lead.id); setActiveScreen("leads"); }}>פתיחת ליד</Button>
                      </div>
                    ))}
                    {followups.length === 0 && <EmptyState title="אין תזכורות פתוחות" subtitle="כל הלידים טופלו או שאין תאריכי Follow-up." />}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeScreen === "tasks" && (
              <div className="grid gap-6 xl:grid-cols-[0.85fr_1.15fr]">
                <Card className="border-0 shadow-sm">
                  <CardContent className="space-y-4 p-5">
                    <div>
                      <h3 className="text-xl font-bold">יצירת משימה חדשה</h3>
                      <p className="mt-1 text-sm text-slate-500">שיוך משימות לעובדים, ללידים ולדדליינים.</p>
                    </div>

                    <Input value={newTask.title} onChange={(e) => setNewTask({ ...newTask, title: e.target.value })} placeholder="כותרת משימה" />
                    <Textarea value={newTask.description} onChange={(e) => setNewTask({ ...newTask, description: e.target.value })} placeholder="פירוט המשימה" className="min-h-24" />

                    <div className="grid gap-3 md:grid-cols-2">
                      <label className="text-sm font-bold">
                        אחראי
                        <select value={newTask.ownerId} onChange={(e) => setNewTask({ ...newTask, ownerId: e.target.value })} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                          {workers.map((worker) => <option key={worker.id} value={worker.id}>{worker.name}</option>)}
                        </select>
                      </label>

                      <label className="text-sm font-bold">
                        עדיפות
                        <select value={newTask.priority} onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                          {priorities.map((priority) => <option key={priority}>{priority}</option>)}
                        </select>
                      </label>

                      <label className="text-sm font-bold">
                        ליד מקושר
                        <select value={newTask.relatedLeadId} onChange={(e) => setNewTask({ ...newTask, relatedLeadId: e.target.value })} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                          <option value="">ללא ליד מקושר</option>
                          {leads.map((lead) => <option key={lead.id} value={lead.id}>{lead.fullName}</option>)}
                        </select>
                      </label>

                      <label className="text-sm font-bold">
                        תאריך יעד
                        <Input type="date" value={newTask.dueDate} onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })} className="mt-2" />
                      </label>
                    </div>

                    <Button onClick={addTask} className="w-full">
                      <Plus className="ml-2 h-4 w-4" />
                      הוספת משימה
                    </Button>

                    <div className="grid gap-3 sm:grid-cols-3">
                      <StatCard icon={ClipboardList} title="כל המשימות" value={taskMetrics.total} />
                      <StatCard icon={Bell} title="פתוחות" value={taskMetrics.open} />
                      <StatCard icon={Check} title="הושלמו" value={taskMetrics.completed} />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm">
                  <CardContent className="p-5">
                    <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div>
                        <h3 className="text-xl font-bold">רשימת משימות</h3>
                        <p className="mt-1 text-sm text-slate-500">מעקב לפי אחראי, סטטוס ודדליין.</p>
                      </div>
                      <div className="grid gap-2 sm:grid-cols-2">
                        <select value={taskStatusFilter} onChange={(e) => setTaskStatusFilter(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                          <option>הכל</option>
                          {taskStatuses.map((status) => <option key={status}>{status}</option>)}
                        </select>
                        <select value={taskOwnerFilter} onChange={(e) => setTaskOwnerFilter(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                          <option value="הכל">כל העובדים</option>
                          {workers.map((worker) => <option key={worker.id} value={worker.id}>{worker.name}</option>)}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {filteredTasks.length === 0 && <EmptyState title="אין משימות להצגה" subtitle="נסי לשנות פילטרים או ליצור משימה חדשה." />}
                      {filteredTasks.map((task) => (
                        <div key={task.id} className="rounded-3xl bg-slate-50 p-4">
                          <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <h4 className="font-bold">{task.title}</h4>
                                <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-600">{task.status}</span>
                                <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-600">עדיפות {task.priority}</span>
                              </div>
                              {task.description && <p className="mt-2 text-sm text-slate-600">{task.description}</p>}
                              <p className="mt-2 text-xs text-slate-500">אחראי: {getWorkerName(task.ownerId)} · ליד: {getLeadName(task.relatedLeadId)} · יעד: {formatDate(task.dueDate)}</p>
                            </div>

                            <div className="grid gap-2 md:w-40">
                              <select value={task.status} onChange={(e) => updateTask(task.id, { status: e.target.value })} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm">
                                {taskStatuses.map((status) => <option key={status}>{status}</option>)}
                              </select>
                              <Button variant="outline" onClick={() => updateTask(task.id, { status: "הושלמה" })}>סמן כהושלמה</Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeScreen === "reports" && (
              <div className="grid gap-6 xl:grid-cols-2">
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-5">
                    <h3 className="mb-4 text-xl font-bold">דוח יומי</h3>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <StatCard icon={ClipboardList} title="לידים היום" value={metrics.incomingToday} />
                      <StatCard icon={Check} title="סגירות" value={metrics.closed} />
                      <StatCard icon={Bell} title="דורשים טיפול" value={metrics.dueFollowups} />
                      <StatCard icon={BarChart3} title="פתוחים" value={metrics.open} />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm">
                  <CardContent className="p-5">
                    <h3 className="mb-4 text-xl font-bold">דוח לפי מקור ליד</h3>
                    <div className="rounded-3xl bg-slate-50 p-4">
                      <div className="flex items-center justify-between border-b border-slate-200 pb-3 font-bold">
                        <span>טופס - דר אירית שחם</span>
                        <span>{leads.length} לידים</span>
                      </div>
                      <div className="mt-3 grid gap-2 text-sm text-slate-600">
                        <div className="flex justify-between"><span>סגירות</span><b>{metrics.closed}</b></div>
                        <div className="flex justify-between"><span>אחוז המרה</span><b>{metrics.conversionRate}%</b></div>
                        <div className="flex justify-between"><span>מכירות</span><b>₪{metrics.totalSales.toLocaleString("he-IL")}</b></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeScreen === "team" && (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-5">
                  <h3 className="mb-4 text-xl font-bold">11 עובדים והרשאות בסיסיות</h3>
                  <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                    {workers.map((worker) => (
                      <div key={worker.id} className="rounded-3xl bg-slate-50 p-4">
                        <div className="mb-3 flex items-center gap-3">
                          <div className="rounded-2xl bg-white p-2">
                            <UserRound className="h-5 w-5 text-slate-500" />
                          </div>
                          <div>
                            <p className="font-bold">{worker.name}</p>
                            <p className="text-xs text-slate-500">{worker.role}</p>
                          </div>
                        </div>
                        <p className="text-sm text-slate-600">צפייה: כל הלידים</p>
                        <p className="text-sm text-slate-600">עריכה: לפי הרשאה</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
